# -*- mode: python ; coding: utf-8 -*-
"""
PyInstaller 打包配置文件 —— 橹穆修仙游戏
用法：
    pyinstaller gamelogic.spec
打包后在 dist/ 目录生成可执行文件（文件夹模式）
"""

import os
import sys
from PyInstaller.utils.hooks import collect_all

block_cipher = None

# 收集 pygame 的全部依赖（二进制、数据、隐藏导入）
pygame_datas, pygame_binaries, pygame_hiddenimports = collect_all('pygame')

# 项目根目录
project_root = os.path.abspath('.')

a = Analysis(
    ['game_ui.py'],
    pathex=[project_root],
    binaries=pygame_binaries,
    datas=pygame_datas + [
        # 打包内置中文字体（确保任何电脑都能显示中文）
        (os.path.join(project_root, 'fonts', 'DroidSansFallbackFull.ttf'), 'fonts'),
    ],
    hiddenimports=pygame_hiddenimports + [
        'gamelogic',  # C++ 扩展模块，显式声明确保被打包
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        # 排除不需要的模块，减小体积
        'tkinter', 'matplotlib', 'numpy', 'scipy', 'pandas',
        'PIL', 'cv2', 'torch', 'tensorflow',
    ],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='LMG_Game',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,  # 启用 UPX 压缩（如果安装了 UPX）
    console=False,  # 不显示控制台黑窗口（GUI程序）
    disable_windowed_traceback=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='LMG_Game',
)
